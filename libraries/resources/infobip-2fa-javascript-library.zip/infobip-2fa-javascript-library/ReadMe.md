# Infobip Two Factor Authentication Javascript library

This project is JavaScript library for requesting Two Factor Authentication.

## Solution description 

Two Factor Authentication is cloud messaging security solution that confirms the identity of the user and protects the system from phishing or hacking attacks.

A one-time PIN (OTP) number is generated and sent to the user's mobile phone. The user receives the OTP and types it into the application to confirm his or her identity. If the PIN code, that was sent out to the user, matches the one that is received, the user is allowed to continue with the process.

## Flow overview 

![](http://i59.tinypic.com/2pq9cbc.png)

1. User enters his phone number into the application (mobile or web).
2. Application sends the request for the PIN code with user's phone number to Infobip.
3. Infobip sends Number context lookup request to the MNO for user’s phone number.
4. Infobip receives Number context lookup response from the MNO.
5. Infobip sends Number context response to the Application.
6. If the Number context result is valid, Infobip generates the PIN code and send it via SMS.
7. MNO delivers SMS with the PIN code.
8. Infobip receives Delivery report for sent message.
9. User enters the received PIN code into the application.
10. Application sends verification request with the PIN code.
11. Infobip verifies the received PIN and sends the response to the application.

>***Note:***

>*Steps 3 and 4 are very important because this is how we verify whether the user entered valid phone number. If the phone number is not valid (i.e. doesn’t exists) we do not even generate the PIN code and send the SMS. This way we prevent unnecessary expenditures for our clients.*

## Step by step integration

1. `infobip-2fa.js` file should be included in the `<head>` section of generated HTML pages.

## Application registration 

In order to use this library, user has to [create an Infobip account](https://accounts.infobip.com/signup) and register mobile application. After registering the application, **application ID** will be obtained, and after creating message for that application, you will get **message ID**.

**API key** can be obtained by calling REST API method for getting this key.

## Initialization 

Initialization is required for using Two Factor Authentication library functions. This can be done by calling `TwoFactorAuth(twoFactorData)` constructor with [TwoFactorData](#twofactordata) JSON as parameter. 

#### TwoFactorData

|Field|Description|
|:----|:----------|
|*applicationId*|The ID of 2-FA application.|
|*apiKey*|This key is used for client authorization and can be obtained by calling appropriate REST API method.|
|*messageId*|Message with given ID will be sent to end user when he or she starts 2-FA process.|

***JSON format:***

```
{
	"applicationId": "APPLICATION_ID",
	"apiKey": "API_KEY",
	"messageId": "MESSAGE_ID"
}
```

### Example

```
var twoFactorData = {
		"applicationId": "A9F4290821F1EE6BC06A8F0792F86035",
		"apiKey": "e99df81a22c9a40d41d328ad19a70c83-9225c21b-e8a5-4021-81da-df81a22c",
		"messageId": "8F0792F86035A9F4290821F1EE6BC06A"
	}

var twoFactorAuth = new TwoFactorAuth(twoFactorData);	
```

After initialization of library object, library functions can be called. Available functions are:

- [`startTwoFactorAuth`](#starting-two-factor-authentication), 
- [`resendPinCode`](#resend-pin),
- [`verifyPin`](#pin-verification),
- [`isVerified`](#checking-if-phone-number-is-verified),
- [`getDeliveryInfo`](#getting-pin-delivery-information).

## Starting Two Factor authentication 

Starting Two Factor Authentication invokes server-side generating PIN code and sending the code to defined destination. That can be done by calling the `startTwoFactorAuth(startTwoFactorAuthData, onSuccess, onError)` function. 

### Function parameters

|Parameter|Description|
|:--------|:----------|
|*startTwoFactorAuthData*|[*StartTwoFactorAuthData*](#starttwofactorauthdata) object. Contains basic information needed for using Two Factor Authentication.|
|*onSuccess*|Function that will be called if status code from server is OK.|
|*onError*|Function that will be called if any error occurs.|

>***Note:***

> Both of the functions `onSuccess` and `onError` can be custom defined in order to determine action after getting response. 

>Both of the functions should have parameter *response*. [`onSuccess`](#onsuccess-response-fields) response will have different format depending on function that it is passed to. [`onError`](#error-response) response has the same format, regardless of the function.

>If any of `onSuccess` and `onError` function is not defined, nothing will happen after `startTwoFactorAuth` function execution.

#### StartTwoFactorAuthData

|Field|Description|
|:--------|:----------|
|*from*|Name that will appear as the sender of the 2-FA message.|
|*to*|Phone number to which PIN code will be sent.|
|*ncNeeded*|If ncNeeded value is `true`, Number context lookup will be requested before sending SMS. If field's value is `false`, SMS will be sent without requesting Number context.|

> ***Note:*** 

>*from* field can have `null` value. In that case, default sender ID will appear as the sender of the 2-FA message.

> *ncNeeded* can have `null` value. In that case, number context will be requested.

***JSON format:***

```
{
	"from": "FROM",
	"to": "TO",
	"ncNeeded": "NC_NEEDED"
}
```

#### onSuccess response fields

|Field|Description|
|:--------|:----------|
|*pinId*|ID of the sent PIN code.|
|*to*|Phone number of PIN code recipient.|
|*ncStatus*|Number context status. This status can take one of these values: `NC_DESTINATION_UNKNOWN`, `NC_DESTINATION_REACHABLE`, `NC_DESTINATION_NOT_REACHABLE` or `NC_NOT_CONFIGURED`.|
|*smsStatus*|Status of sent message. This status can take one of these values: `MESSAGE_SENT` or `MESSAGE_NOT_SENT`.|

> ***Note:***

>If you get `NC_NOT_CONFIGURED` status, you should **contact your account manager** for configuring it. 

>SMS **will not be sent** only if *ncStatus* value is `NC_NOT_REACHABLE`.

***JSON format:***

```
{
	"pinId": "PIN_ID",
	"to": "TO",
	"ncStatus": "NC_STATUS",
	"smsStatus":"SMS_STATUS"
}
```

If any error occurs during function execution, `onError` function will be called with [*error response*](#error-response) parameter.

### Example

#### Request

```
var onSuccess = function(jsonResponse){
	console.log("Success: " + jsonResponse);
}

var onError = function(jsonResponse){
	console.log("Error: " + jsonResponse);
}

var startTwoFactorAuthData = {
	"from": "InfoSMS",
	"to": "41793026727",
	"ncNeeded": true
}

twoFactorAuth.startTwoFactorAuth(startTwoFactorAuthData, onSuccess, onError);		
```	
#### Response

```
{
	"pinId": "1DA742B334365527E7FBD8ACC02F7F562",
	"to": "41793026727",
	"ncStatus": "NC_DESTINATION_NOT_REACHABLE",
	"smsStatus": "MESSAGE_NOT_SENT"
}
```	

## Resend PIN ##

If you want to send the same PIN code to the same phone number, you can do it by calling the `resendPinCode(pinId, onSuccess, onError)` function.

### Function parameters

|Parameter|Description|
|:----|:-----|
|*pinId*|ID of the PIN code that has to be resent.|
|*onSuccess*|Function that will be called if status code from server is OK.|
|*onError*|Function that will be called if some error occurs.|

>***Note:*** 

>Both of the functions `onSuccess` and `onError` can be custom defined in order to determine action after getting response. 

>Both of the functions should have parameter *response*. [`onSuccess`](#onsuccess-response-fields-1) response will have different format depending on function that it is passed to. [`onError`](#error-response) response has the same format, regardless of the function.

>***Note***: If any of `onSuccess` and `onError` function is not defined, nothing will happen after `resendPinCode` function execution.

#### onSuccess response fields

|Field|Description|
|:--------|:----------|
|*pinId*|ID of the sent PIN code.|
|*to*|Phone number of pin code recipient.|
|*ncStatus*|number context status. This status can take one of these values: `NC_DESTINATION_UNKNOWN`, `NC_DESTINATION_REACHABLE`, `NC_DESTINATION_NOT_REACHABLE` or `NC_NOT_CONFIGURED`.|
|*smsStatus*|Status of sent message. This status can take one of these values: `MESSAGE_SENT` or `MESSAGE_NOT_SENT`.|

***JSON format:***

```
{
	"pinId": "PIN_ID",
	"to": "TO",
	"ncStatus": "NC_STATUS",
	"smsStatus":"SMS_STATUS"
}
```

If any error occurs during function execution, onError function will be called with [*error response*](#error-response) parameter.

### Example

#### Request

```
var onSuccess = function(jsonResponse){
	console.log("Success: " + jsonResponse);
}

var onError = function(jsonResponse){
	console.log("Error: " + jsonResponse);
}

twoFactorAuth.startTwoFactorAuth("1DA742B334365527E7FBD8ACC02F7F562", onSuccess, onError);		
```	
#### Response

```
{
	"pinId": "1DA742B334365527E7FBD8ACC02F7F562",
	"to": "41793026727",
	"ncStatus": "NC_DESTINATION_REACHABLE",
	"smsStatus": "MESSAGE_SENT"
}
```	

##Pin Verification##

In order to continue the process, a one-time PIN (OTP) code that was generated and sent to user, needs to be verified. User will enter PIN code and if it matches the one that is received, he will be allowed to continue the process. 

Function that need to be called in order to verify PIN code is `verifyPin(pinId, pinCode, onSuccess, onError)` function.

### Function parameters

|Parameter|Description|
|:--------|:----------|
|*pinId*|ID of the PIN that has to be verified.|
|*pinCode*|PIN code received by user.|
|*onSuccess*|Function that will be called if status code from server is OK.|
|*onError*|Function which will be called if any error occurs.|

>***Note:***

>Both of the functions `onSuccess` and `onError` can be custom defined in order to determine action after getting response. 

>Both of the functions should have parameter *response*. [`onSuccess`](#onsuccess-response-fields-2) response will have different format depending on function that it is passed to. [`onError`](#error-response) response has the same format, regardless of the function.

>If any of `onSuccess` and `onError` function is not defined, nothing will happen after `verifyPin` function execution.

#### onSuccess response fields

|Field|Description|
|:----|:----------|
|*pinId*|ID of the pin code for which verification process was started.|
|*msisdn*|Msisdn (phone number) for which verification process was started.|
|*verified*|Returns `TRUE` or `FALSE` depending on correctness of sent pin code.|
|*attemptsRemaining*|Number of remaining PIN attempts.|
|*pinError*|Tells if any error occurred during PIN verification. This field can have one of the following values: `WRONG_PIN`, `TTL_EXPIRED`, `NO_MORE_PIN_ATTEMPTS`.|

> ***Note:***

> *pinError* field will have `WRONG_PIN` value if passed PIN code doesn't match sent PIN code, `TTL_EXPIRED` if PIN time to live has expired and PIN code is no longer valid, and `NO_MORE_PIN_ATTEMPTS` if there are no more possible PIN attempts.

***JSON format:***

```
{
	"pinId": "PIN_ID",
	"msisdn": "MSISDN",
	"verified": "VERIFIED",
	"attemptsRemaining": "ATTEMPTS_REMAINING",
	"pinError": "PIN_ERROR"
}
```

If any error occurs during function execution, `onError` function will be called with [*error response*](#error-response) parameter.

### Example

#### Request
 
```
var onSuccess = function(jsonResponse){
	console.log("Success: " + jsonResponse);
}

var onError = function(jsonResponse){
	console.log("Error: " + jsonResponse);
}

twoFactorAuth.verifyPin("1DA742B334365527E7FBD8ACC02F7F562","7c32a" onSuccess, onError);
```

#### Response

```
{
	"pinId": "1DA742B334365527E7FBD8ACC02F7F562",
	"msisdn": "41793026727",
	"verified": true,
	"attemptsRemaining": 0
}
```
	
## Checking if phone number is verified 

In every moment you can check if phone number is already verified. That can be done by calling `isVerified(verificationCheckData, onSuccess, onError)` function. 

### Function parameters

|Parameter|Description|
|:--------|:----------|
|*verificationCheckData*|[*VerificationCheckData*](#verificationcheckdata) object. Contains information needed for checking verification.|
|*onSuccess*|Function that will be called if status code from server is OK.|
|*onError*|Function which will be called if any error occurs.|

>***Note:***

>Both of the functions `onSuccess` and `onError` can be custom defined in order to determine action after getting response. 

>Both of the functions should have parameter *response*. [`onSuccess`](#onsuccess-response-fields-3) response will have different format depending on function that it is passed to. [`onError`](#error-response) response has the same format, regardless of the function.

>If any of `onSuccess` and `onError` function is not defined, nothing will happen after `isVerified` function execution.

#### VerificationCheckData

|Field|Description|
|:--------|:----------|
|*msisdn*|Filter by msisdn (phone number).|
|*verified*|Filter by verified status (`TRUE` or `FALSE`).|
|*sent*|Filter by message sent status (`TRUE` or `FALSE`).|

#### onSuccess response fields

Array of [*VerificationStatus*](#verificationstatus) objects.

##### VerificationStatus

|Field|Description|
|:----|:----------|
|*msisdn*|Msisdn (phone number) for which verification status is checked.|
|*verified*|Tells whether the phone number is verified or not.|
|*verifiedAt*|If number is verified, this field contains UNIX timestamp (in millis) of verification time.|
|*sentAt*|If message is sent to msisdn, this field contains UNIX timestamp (in millis) of sending time.|

***JSON format:***

```
{
	"msisdn": "MSISDN",
	"verified" : "VERIFIED",		
	"sent": "SENT"
}
```

If any error occurs during function execution, `onError` function will be called with [*error response*](#error-response) parameter.

### Example

#### Request

```
var onSuccess = function(jsonResponse){
	console.log("Success: " + jsonResponse);
}

var onError = function(jsonResponse){
	console.log("Error: " + jsonResponse);
}

var verificationCheckData = {
	"msisdn": "41793026727",
	"sent": true
}

twoFactorAuth.isVerified(verificationCheckData, onSuccess, onError);
```

#### Response

```
[
	{
		"msisdn":"41793026727",
		"verified":false,
		"verifiedAt":0,
		"sentAt":1416487030434
	},
	{
		"msisdn":"41793026727",
		"verified":false,
		"verifiedAt":0,
		"sentAt":1418808679097
	}
]
```

## Getting PIN delivery information 

After sending PIN code to end user, you may want to know if PIN code is delivered. This can be done by requesting PIN delivery information. 

This information should be requested by calling `getDeliveryInfo(pinId, onSuccess, onError)` function.

### Function parameters

|Parameter|Description|
|:--------|:----------|
|*pinId*|ID of PIN code for which delivery information is requested.| 
|*onSuccess*|Function that will be called if status code from server is OK.|
|*onError*|Function which will be called if any error occurs.|

>***Note***: 

>Both of the functions `onSuccess` and `onError` can be custom defined in order to determine action after getting response. 

>Both of the functions should have parameter *response*. [`onSuccess`](#onsuccess-response-fields-4) response will have different format depending on function that it is passed to. [`onError`](#error-response) response has the same format, regardless of the function.

>If any of `onSuccess` and `onError` function is not defined, nothing will happen after `getDeliveryInfo` function execution.

#### onSuccess response fields

Array of [*DeliveryInfo*](#deliveryinfo) objects.

##### DeliveryInfo

|Field|Description|
|:----|:----------|
|*status*|Sent SMS delivery status. Possible status values are listed [here](#delivery-status-values).|
|*description*|Sent SMS delivery status description.|
|*finalStatus*|Tells if SMS delivery status is final.|

***JSON format:***

```
[
	{
		"status": "SMS_STATUS",
		"description": "STATUS_DESCRIPTION",
		"finalStatus": "IS_STATUS_FINAL" 		
	}
]
```

If any error occurs during function execution, `onError` function will be called with [*error response*](#error-response) parameter.

#### Delivery status values

|Status|Description|FinalStatus|
|:---|:---|:---|
|``MESSAGE_ACCEPTED``|Message accepted|true|
|``MESSAGE_NOT_SENT``|Message not sent|false|
|``MESSAGE_NOT_DELIVERED``|Message sent, not delivered|true|
|``MESSAGE_WAITING_DELIVERY``|Message sent, waiting for delivery|false|
|``MESSAGE_DELIVERED``|Message sent and delivered|true|
|``MESSAGE_NETWORK_NOT_ALLOWED``|Message not sent, network not allowed|true|
|``MESSAGE_NETWORK_NOT_AVAILABLE``|Message not sent, bulk or gateway offline|true|
|``MESSAGE_INVALID_DESTINATION_ADDRESS``|Message not sent, invalid destination address|true|
|``MESSAGE_DELIVERY_UNKNOWN``|Message delivery unknown|true|
|``INVALID_SOURCE_ADDRESS``|Message not sent, invalid source address|true|
|``NOT_ENOUGH_CREDITS``|Message not sent, not enough credits|true|
|``MESSAGE_REJECTED``|Message rejected|true|
|``MESSAGE_EXPIRED``|Message expired|true|
|``SYSTEM_ERROR``|System error|true|

### Examples

#### Request

```
var onSuccess = function(jsonResponse){
	console.log("Success: " + jsonResponse);
}

var onError = function(jsonResponse){
	console.log("Error: " + jsonResponse);
}

twoFactorAuth.getDeliveryInfo("1DA742B334365527E7FBD8ACC02F7F562", onSuccess, onError);
```

#### Response

```
[	
	{
		"status": "MESSAGE_DELIVERED",
		"description": "Message sent and delivered",
		"finalStatus": true
	},
	{
		"status": "MESSAGE_WAITING_DELIVERY",
		"description": "Message sent, waiting for delivery",
		"finalStatus": false
	}
]
```

## Error response

|Field|Description|
|:----|:----------|
|*requestError*|[*RequestError*](#requesterror) object.|

#### RequestError

|Field|Description|
|:----|:----------|
|*serviceException*|[*ServiceException*](#serviceexception) object. Contains information about error that occurred.|

#### ServiceException

|Field|Description|
|:----|:----------|
|*messageId*|ID of an error. This field can have one of the following values: `INVALID_ARGUMENT`, `UNAUTHORIZED`, `RESOURCE_NOT_FOUND`, `THROTTLE_EXCEPTION`, `GENERAL_EXCEPTION`, `SERVICE_UNAVAILABLE`.|
|*text*|A short description of the cause of the error.|

***JSON format:***

```
{
	"requestError": {
		"serviceException": {
			"messageId": "MESSAGE_ID",
            "text": "TEXT"
        }
    }
}
```

### Example

```
{
    "requestError": {
        "serviceException": {
            "messageId": "RESOURCE_NOT_FOUND",
            "text": "Application or message with given ID cannot be found."
        }
    }
}
```

## Owners

Team Infobip Products @ Infobip Belgrade, Serbia

© 2014, Infobip Ltd.