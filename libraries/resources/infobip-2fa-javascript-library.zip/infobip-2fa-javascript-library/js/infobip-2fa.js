/**
 * Created by nmenkovic on 28.8.2014.
 */

TwoFactorAuth.prototype.apiKey = {};
TwoFactorAuth.prototype.applicationId = {};
TwoFactorAuth.prototype.messageId = {};

function TwoFactorAuth(twoFactorData) {
    this.apiKey = twoFactorData["apiKey"];
    this.applicationId = twoFactorData["applicationId"];
    this.messageId = twoFactorData["messageId"];
}

var BASE_URL = "//oneapi.infobip.com/2fa/1";

TwoFactorAuth.prototype.onXHRLoad = function (xhr, onSuccess, onError) {
    if (xhr.readyState === 4) {
        if (xhr.status >= 200 && xhr.status < 300) {
            if (onSuccess !== undefined) onSuccess(JSON.parse(xhr.responseText));
        } else {
            if (onError !== undefined) onError(JSON.parse(xhr.responseText));
        }
    }
};

TwoFactorAuth.prototype.startTwoFactorAuth = function (startTwoFactorAuthData, onSuccess, onError) {
    if (this.apiKey === undefined || this.applicationId === undefined || this.messageId === undefined || startTwoFactorAuthData === undefined || startTwoFactorAuthData["to"] === undefined) {
        onError({"requestError": {"serviceException": {"messageId": "INVALID_ARGUMENT", "text": "Invalid argument."}}});
    }

    if (startTwoFactorAuthData["from"] === undefined) {
        startTwoFactorAuthData["from"] = null;
    }
    if (startTwoFactorAuthData["ncNeeded"] === undefined) {
        startTwoFactorAuthData["ncNeeded"] = null;
    }

    var url = BASE_URL + "/pin/sms?ncNeeded=" + startTwoFactorAuthData["ncNeeded"];

    var body = {
        "applicationId": this.applicationId,
        "messageId": this.messageId,
        "from": startTwoFactorAuthData["from"],
        "to": startTwoFactorAuthData["to"]
    };

    var _this = this;
    var httpRequest = new XMLHttpRequest();
    httpRequest.open("POST", url, true);
    httpRequest.setRequestHeader("Authorization", "App " + this.apiKey);
    httpRequest.setRequestHeader("Content-Type", "application/json");
    httpRequest.setRequestHeader("Accept", "application/json");
    httpRequest.onload = function () {
        _this.onXHRLoad(httpRequest, onSuccess, onError);
    };
    httpRequest.onerror = function () {
        onError(JSON.parse(httpRequest.responseText));
    };
    httpRequest.send(JSON.stringify(body));
};

TwoFactorAuth.prototype.resendPinCode = function (pinId, onSuccess, onError) {
    if (this.apiKey === undefined || pinId === undefined) {
        onError({"requestError": {"messageId": "INVALID_ARGUMENT", "text": "Invalid argument."}});
    }

    var url = BASE_URL + "/pin/" + pinId + "/resend/sms";
    var _this = this;
    var httpRequest = new XMLHttpRequest();
    httpRequest.open("POST", url, true);
    httpRequest.setRequestHeader("Authorization", "App " + this.apiKey);
    httpRequest.setRequestHeader("Content-Type", "application/json");
    httpRequest.setRequestHeader("Accept", "application/json");
    httpRequest.onload = function () {
        _this.onXHRLoad(httpRequest, onSuccess, onError);
    };
    httpRequest.onerror = function () {
        onError(JSON.parse(httpRequest.responseText));
    };
    httpRequest.send();
};

TwoFactorAuth.prototype.verifyPin = function (pinId, pinCode, onSuccess, onError) {
    if (this.apiKey === undefined || this.applicationId === undefined || pinCode === undefined || pinId === undefined) {
        onError({"requestError": {"messageId": "INVALID_ARGUMENT", "text": "Invalid argument."}});
    }

    var url = BASE_URL + "/pin/" + pinId + "/verify";
    var body = {
        "pin": pinCode
    };

    var _this = this;
    var httpRequest = new XMLHttpRequest();
    httpRequest.open("POST", url, true);
    httpRequest.setRequestHeader("Authorization", "App " + this.apiKey);
    httpRequest.setRequestHeader("Content-Type", "application/json");
    httpRequest.setRequestHeader("Accept", "application/json");
    httpRequest.onload = function () {
        _this.onXHRLoad(httpRequest, onSuccess, onError);
    };
    httpRequest.onerror = function () {
        onError(JSON.parse(httpRequest.responseText));
    };
    httpRequest.send(JSON.stringify(body));
};

TwoFactorAuth.prototype.isVerified = function (verificationCheckData, onSuccess, onError) {
    if (this.apiKey === undefined || this.applicationId === undefined || verificationCheckData === undefined || verificationCheckData["msisdn"] === undefined) {
        onError({"requestError": {"messageId": "INVALID_ARGUMENT", "text": "Invalid argument."}});
    }

    var url = BASE_URL + "/applications/" + this.applicationId + "/verifications?msisdn=" + verificationCheckData["msisdn"];
    if (verificationCheckData["verified"] !== undefined) url = url + "&verified=" + verificationCheckData["verified"];
    if(verificationCheckData["sent"] != undefined) url = url + "&sent=" + verificationCheckData["sent"];

    var _this = this;
    var httpRequest = new XMLHttpRequest();
    httpRequest.open("GET", url, true);
    httpRequest.setRequestHeader("Authorization", "App " + this.apiKey);
    httpRequest.setRequestHeader("Accept", "application/json");
    httpRequest.onload = function () {
        _this.onXHRLoad(httpRequest, onSuccess, onError);
    };
    httpRequest.onerror = function () {
        onError(JSON.parse(httpRequest.responseText));
    };
    httpRequest.send();
};

TwoFactorAuth.prototype.getDeliveryInfo = function (pinId, onSuccess, onError) {
    if (this.apiKey === undefined || pinId === undefined) {
        onError({"requestError": {"messageId": "INVALID_ARGUMENT", "text": "Invalid argument."}});
    }

    var url = BASE_URL + "/pin/" + pinId + "/status/sms";
    var _this = this;
    var httpRequest = new XMLHttpRequest();
    httpRequest.open("GET", url, true);
    httpRequest.setRequestHeader("Authorization", "App " + this.apiKey);
    httpRequest.setRequestHeader("Content-Type", "application/json");
    httpRequest.setRequestHeader("Accept", "application/json");
    httpRequest.onload = function () {
        _this.onXHRLoad(httpRequest, onSuccess, onError);
    };
    httpRequest.onerror = function () {
        onError(JSON.parse(httpRequest.responseText));
    };
    httpRequest.send();
};